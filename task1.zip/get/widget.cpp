#include "widget.h"
#include "ui_widget.h"
#include <sys/types.h>
#include <sys/sem.h>
#include <stdio.h>
#include <sys/shm.h>
//#include <sys/ipc.h>
#include <stdlib.h>
#include <cstdio>
#include <QMessageBox>
#include <QFile>

#define KEY1 7778
#define KEY2 3331
//P V 操作定义
void P(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = -1;
    sem.sem_flg = 0;       //操作标记：0或IPC_NOWAIT等
    semop(semid, &sem, 1); //1:表示执行命令的个数
    return;
}

void V(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = 1;
    sem.sem_flg = 0;
    semop(semid, &sem, 1);
    return;
}

//信号灯、线程句柄定义：
int semid, shmid;


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->setWindowTitle(QString("GET"));
    ui->textEdit->setReadOnly(true);
    ui->progressBar->setRange(0, 100);
    ui->progressBar->reset();

    //file size
    QFile file("/home/zz7/CodeForC/osCD/input");
    if (!file.open(QIODevice::ReadOnly)) printf("file open error!");
    int totalSize = file.size();
    file.close();
    // 创建信号灯；
    semid = semget(KEY1, 4, IPC_CREAT | 0666);
    if (semid == -1){
        printf("信号灯创建失败！\n");
    }


        //信号灯赋初值；
//    semctl(semid,0,SETVAL,1);     //s1
//    semctl(semid,1,SETVAL,0);     //t1
//    semctl(semid,2,SETVAL,1);    //s2
//    semctl(semid,3,SETVAL,0);    //t2

    //创建共享内存
    shmid = shmget(KEY2, 200, IPC_CREAT | 0666);
    if ((shmid) == -1){
        printf("创建共享内存失败！\n");
    }
    char * buf ;
    buf =(char *) shmat(shmid, 0, 0);

    FILE * fp;
    if ((fp = fopen("/home/zz7/CodeForC/osCD/input", "rb")) == NULL){
        printf("待读文件无法打开!\n");
        shmdt(buf);
        fclose(fp);
    }

    connect(ui->pushButton, &QPushButton::clicked, this, [=](){
        ui->textEdit->insertPlainText(QString("Start!\n"));
        int bitlen;
        int total = 0;
        while(!feof(fp)){

            P(semid, 0);
            bitlen = fread(buf+1, 1, 50, fp);  //写进来
            buf[0] = bitlen;

            QString str;
            for (int i = 1; i <= bitlen; i++){
                str = str + buf[i];
            }
            V(semid, 1);
            ui->textEdit->insertPlainText(QString("%1字符进入缓冲区，为：\n%2\n").arg(QString::number(bitlen), str));
            total += bitlen;
            ui->progressBar->setValue(total * 100 / totalSize);

        }

        fclose(fp);
        shmdt(buf);
    });




}

Widget::~Widget()
{
    delete ui;
}
