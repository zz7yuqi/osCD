#include "widget.h"
#include "ui_widget.h"
#include <sys/types.h>
#include <sys/sem.h>
#include <stdio.h>
#include <sys/shm.h>
//#include <sys/ipc.h>
#include <stdlib.h>
#include <cstdio>
#include <QMessageBox>
#include <QFile>

#define KEY1 7778
#define KEY2 3331
//P V 操作定义
void P(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = -1;
    sem.sem_flg = 0;       //操作标记：0或IPC_NOWAIT等
    semop(semid, &sem, 1); //1:表示执行命令的个数
    return;
}

void V(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = 1;
    sem.sem_flg = 0;
    semop(semid, &sem, 1);
    return;
}

//信号灯、线程句柄定义：
int semid, shmid;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->setWindowTitle(QString("COPY"));
    ui->textEdit->setReadOnly(true);
    ui->progressBar->setRange(0, 100);
    ui->progressBar->reset();

    //file size
    QFile file("/home/zz7/CodeForC/osCD/input");
    if (!file.open(QIODevice::ReadOnly)) printf("file open error!");
    int totalSize = file.size();
    file.close();
    // 创建信号灯；
    semid = semget(KEY1, 4, IPC_CREAT | 0666);
    if (semid == -1){
        printf("信号灯创建失败！\n");
    }

      //信号灯赋初值；
    //    semctl(semid,0,SETVAL,1);     //s1
    //    semctl(semid,1,SETVAL,0);     //t1
    //    semctl(semid,2,SETVAL,1);    //s2
    //    semctl(semid,3,SETVAL,0);    //t2

    //创建共享内存
    shmid = shmget(KEY2, 100, IPC_CREAT | 0666);
    if ((shmid) == -1){
        printf("创建共享内存失败！\n");
    }
    char * buf1, * buf2 ;
    buf1 =(char *) shmat(shmid, 0, 0);
    buf2 = buf1 + 100;

    connect(ui->pushButton, &QPushButton::clicked, this, [=](){
       ui->textEdit->insertPlainText(QString("Start!\n"));
       int buf1len = 50;
       int total = 0;
       while(buf1len == 50){

           QString str;
           P(semid, 1);
           buf1len = (int)buf1[0];
           for (int i = 1; i <= buf1len; i++) str += buf1[i];
           V(semid, 0);

           ui->textEdit->insertPlainText(QString("从1号缓冲区获得%1个字符数据，为：%2\n").arg(QString::number(buf1len), str));
           char *sstr;
           QByteArray ba = str.toLatin1();
           sstr = ba.data();

           P(semid, 2);
           for (int i = 1; i <= buf1len; i++){
               buf2[i] = sstr[i-1];
           }
           buf2[0] = buf1len;
           ui->textEdit->insertPlainText(QString("向2号缓冲区写入%1个字符数据，为：%2\n").arg(QString::number(buf1len), str));
           V(semid, 3);
           total += buf1len;
           ui->progressBar->setValue(total * 100 / totalSize);
       }
    });


}

Widget::~Widget()
{
    delete ui;
}
