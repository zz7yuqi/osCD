#include "widget.h"
#include "ui_widget.h"
#include <sys/types.h>
#include <sys/sem.h>
#include <stdio.h>
#include <sys/shm.h>
//#include <sys/ipc.h>
#include <stdlib.h>
#include <cstdio>
#include <QFile>

#define KEY1 7778
#define KEY2 3331
//P V 操作定义
void P(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = -1;
    sem.sem_flg = 0;       //操作标记：0或IPC_NOWAIT等
    semop(semid, &sem, 1); //1:表示执行命令的个数
    return;
}

void V(int semid, int index)
{
    struct sembuf sem;
    sem.sem_num = index;
    sem.sem_op = 1;
    sem.sem_flg = 0;
    semop(semid, &sem, 1);
    return;
}

//信号灯、线程句柄定义：
int semid, shmid;


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{

    ui->setupUi(this);
    this->setWindowTitle(QString("PUT"));
    ui->textEdit->setReadOnly(true);
    ui->progressBar->setRange(0, 100);
    ui->progressBar->reset();

    //file size
    QFile file("/home/zz7/CodeForC/osCD/input");
    if (!file.open(QIODevice::ReadOnly)) printf("file open error!");
    int totalSize = file.size();
    file.close();

    // 创建信号灯；
    semid = semget(KEY1, 4, IPC_CREAT | 0666);
    if (semid == -1){
        printf("信号灯创建失败！\n");
    }

        //信号灯赋初值；
//        semctl(semid,0,SETVAL,1);     //s1
//        semctl(semid,1,SETVAL,0);     //t1
//        semctl(semid,2,SETVAL,1);    //s2
//        semctl(semid,3,SETVAL,0);    //t2

    //创建共享内存
    shmid = shmget(KEY2, 200, IPC_CREAT | 0666);
    if ((shmid) == -1){
        printf("创建共享内存失败！\n");
    }
    char * buf ;
    buf =(char *) shmat(shmid, 0, 0);
    buf = buf + 100;

    FILE * fp;
    if ((fp = fopen("/home/zz7/CodeForC/osCD/output", "wb")) == NULL){
        printf("待xie文件无法打开!\n");
        shmdt(buf);
        fclose(fp);
    }

    connect(ui->btn_start, &QPushButton::clicked, this, [=](){
        ui->textEdit->insertPlainText(QString("Start!\n"));
        int total = 0;
        int buflen = 50;
        while(buflen == 50){
            P(semid, 3);
            buflen = (int)buf[0];
            QString str;
            for (int i = 1; i <= buflen; i++){
                str += buf[i];
            }
            V(semid, 2);
            ui->textEdit->insertPlainText(QString("从缓冲区2中获得%1个字符，为：%2\n").arg(QString::number(buflen), str));
            total += buflen;
            ui->progressBar->setValue(total*100/totalSize);
            fwrite(buf+1, 1, buflen, fp);

        }
        fclose(fp);
    });
}

Widget::~Widget()
{
    delete ui;
}
