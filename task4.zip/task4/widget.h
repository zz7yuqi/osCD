#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QVector>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget *ui;
    QTimer * timerTab0 = new QTimer();
    int nTimer = 0;    //记录定时器第几次响应
    QVector<double> tt, rrate;  //cpu使用率
    QVector<double> ttMem, rrateMem;  //内存
    QVector<double> ttSwap, rrateSwap; //交换区
    void Sleep(int msec);
    int isDigitStr(QString src);
    void refresh();
    void addProcList(QString & tempName);
    void displayModulesInfo();
    int numOfSleep = 0, numOfZombie = 0, numOfRun = 0, numOfProc = 0;
};

#endif // WIDGET_H
