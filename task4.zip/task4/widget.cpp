#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QTabWidget>
#include <QMessageBox>
#include <QDebug>
#include <QProcess>
#include <QDir>
#include <QListWidget>
#include <QHeaderView>
#include <QtAlgorithms>
#include <QTextStream>
#include <QFileDialog>

bool caseInsensitiveLessThan(const QString &s1, const QString &s2)
{
    return s1.toInt() < s2.toInt();
}

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("系统监视器");

    //系统信息
    {
        //获得CPU名称，类型，频率，大小
        QFile fCPU("/proc/cpuinfo");
        fCPU.open(QIODevice::ReadOnly);

        QString * bufCPU = new QString(fCPU.readAll());
        //获取cpu类型
        int from = bufCPU->indexOf("vendor_id");
        int end = bufCPU->indexOf("cpu family");
        QString * cpuType = new QString(bufCPU->mid(from + 12, end - from - 13));
        //获取cpu名称
        from = bufCPU->indexOf("model name");
        end = bufCPU->indexOf("stepping");
        QString * cpuName = new QString(bufCPU->mid(from + 12, end - from - 13));
        //获取cpu主频
        from = bufCPU->indexOf("cpu MHz");
        end = bufCPU->indexOf("cache size");
        QString * cpuFreq = new QString(bufCPU->mid(from + 12, end - from - 13));
        //获取cache大小
        from = bufCPU->indexOf("cache size");
        end = bufCPU->indexOf("physical id");
        QString * cacheSize = new QString(bufCPU->mid(from + 12, end - from - 13));
        //加载至相应控件上
        ui->labelCPUfreq->setText(*cpuFreq+" MHz");
        ui->labelCPUname->setText(*cpuName);
        ui->labelCachesize->setText(*cacheSize);
        ui->labelCPUtype->setText(*cpuType);

        //获取操作系统类型，版本，gcc版本
        QFile fos("/proc/version");
        fos.open(QIODevice::ReadOnly);

        QString * bufos = new QString(fos.readAll());
        //获取操作系统类型
        from = 0;
        end = bufos->indexOf(" ");
        QString osType = bufos->mid(from, end - from);
        //获取操作系统版本
        from = osType.length() + 1 + 7 + 1;
        end = bufos->indexOf(" ", from);
        QString osVersion = bufos->mid(from, end - from);
        //获取gcc版本
        from = bufos->indexOf("gcc version");
        end = bufos->indexOf("#");
        QString gccVersion = bufos->mid(from + 12, end - from - 14);


        //加载至相应控件
        ui->labelOstype->setText(osType);
        ui->labelOsversion->setText(osVersion);
        ui->labelGcctype->setText(gccVersion);
        fCPU.close();
        fos.close();
    }

    //内存资源
    {
        //初始化数组tt[121], rrate[121]
        for (int i = 0; i < 121; i++){
            tt.push_back((double)i);
            rrate.push_back(0);
            ttMem.push_back((double)i);
            rrateMem.push_back(0);
            ttSwap.push_back((double)i);
            rrateSwap.push_back(-20);
        }

        //初始化cpu使用率曲线图
        ui->customPlot->xAxis->setRange(0, 125);// 设置坐标轴的范围，以看到所有数据
        ui->customPlot->yAxis->setLabel("CPU使用率");
        ui->customPlot->yAxis->setRange(0, 100);
        ui->customPlot->replot();// 重画图像

        //初始化mem使用率曲线图
        ui->customPlotMem->xAxis->setRange(0, 125);// 设置坐标轴的范围，以看到所有数据
        ui->customPlotMem->yAxis->setLabel("内存使用率");
        ui->customPlotMem->yAxis->setRange(0, 100);
        ui->customPlotMem->replot();// 重画图像

        //初始化swap使用率曲线图
        ui->customPlotSwap->xAxis->setRange(0, 125);// 设置坐标轴的范围，以看到所有数据
        ui->customPlotSwap->yAxis->setLabel("交换分区使用率");
        ui->customPlotSwap->yAxis->setRange(-20, 100);
        ui->customPlotSwap->replot();// 重画图像



        connect(timerTab0, &QTimer::timeout, this, [&](){
            //qDebug() << "!\n";   //测试计时器功能
            //每隔相应时间对信息更新

            //更新内存信息
            {
                QFile fMem("/proc/meminfo");
                fMem.open(QIODevice::ReadOnly);
                QString memInfo(fMem.readAll());
                fMem.close();
                //获得内存容量
                int from = memInfo.indexOf("MemTotal");
                int end = memInfo.indexOf("MemFree");
                QString memTotal = memInfo.mid(from + 17, end - from -21);
                memTotal = QString::number(memTotal.toInt() / 1024);   //KB to MB
                //获得剩余内存容量
                from = memInfo.indexOf("MemFree");
                end = memInfo.indexOf("MemAvailable");
                QString memFree = memInfo.mid(from + 17, end - from -21);
                memFree = QString::number(memFree.toInt() / 1024);   //KB to MB
                //通过计算获得已用内存容量
                QString memUsed = QString::number(memTotal.toInt() - memFree.toInt());
                //计算内存使用百分比
                int memUsedrate = (memUsed.toInt() * 100) / (memTotal.toInt());
                QString memUsedratestr = QString::number(memUsedrate);

                //获得交换容量
                from = memInfo.indexOf("SwapTotal");
                end = memInfo.indexOf("SwapFree");
                QString swapTotal = memInfo.mid(from + 17, end - from -21);
                swapTotal = QString::number(swapTotal.toInt() / 1024);   //KB to MB
                //获得剩余交换容量
                from = memInfo.indexOf("SwapFree");
                end = memInfo.indexOf("Dirty");
                QString swapFree = memInfo.mid(from + 17, end - from -21);
                swapFree = QString::number(swapFree.toInt() / 1024);   //KB to MB
                //通过计算获得已用交换容量
                QString swapUsed = QString::number(swapTotal.toInt() - swapFree.toInt());
                //计算交换使用百分比
                int swapUsedrate = (swapUsed.toInt() * 100) / (swapTotal.toInt());
                QString swapUsedratestr = QString::number(swapUsedrate);


                ui->labelMemtotal->setText(memTotal + " MB");
                ui->labelMemleft->setText(memFree + " MB");
                ui->labelMemused->setText(memUsed + " MB");
                ui->labelMemUserate->setText(memUsedratestr + "%");
                ui->progressBarMem->setValue(memUsedrate);

                ui->labelSwaptotal->setText(swapTotal + " MB");
                ui->labelSwapleft->setText(swapFree + " MB");
                ui->labelSwapused->setText(swapUsed + " MB");
                ui->labelSwaprate->setText(swapUsedratestr + "%");
                ui->progressBarSwap->setValue(swapUsedrate);

                //绘制曲线
                rrateMem[nTimer] = (double)memUsedrate;
                ui->customPlotMem->addGraph();
                ui->customPlotMem->graph(0)->setData(ttMem, rrateMem);
                ui->customPlotMem->replot();

                rrateSwap[nTimer] = (double)swapUsedrate;
                ui->customPlotSwap->addGraph();
                ui->customPlotSwap->graph(0)->setData(ttSwap, rrateSwap);
                ui->customPlotSwap->replot();
            }


            //更新cpu使用率
            {
                //获得cpu频率

                QFile fstat("/proc/stat");
                fstat.open(QIODevice::ReadOnly);
                QString firstLine = fstat.readLine();
                unsigned int total1,total2,idle1,idle2,total,idle;

                QStringList dataforcal = firstLine.split(' ');  //dataforcal[2..10]为有效数据 dataforcal[5]为idle
                idle1 = (dataforcal[5]).toUInt();
                //计算total1
                total1 = 0;
                for (int i = 2; i <= 10; i++) total1 += (dataforcal[i]).toUInt();
                //qDebug() << dataforcal <<endl;

                fstat.close();
                this->Sleep(20);
                //获得total2 idle2
                QFile fstat2("/proc/stat");
                fstat2.open(QIODevice::ReadOnly);
                firstLine = fstat2.readLine();

                dataforcal = firstLine.split(' ');  //dataforcal[2..10]为有效数据 dataforcal[5]为idle
                idle2 = (dataforcal[5]).toUInt();
                //计算total2
                total2 = 0;
                for (int i = 2; i <= 10; i++) total2 += (dataforcal[i]).toUInt();
                //qDebug() << dataforcal <<endl;

                fstat2.close();

                //计算total和idle
                total = total2 - total1;
                idle = idle2 - idle1;
                int cpuUsedrate = 100*(total-idle)/total;
                ui->progressBar->setValue(cpuUsedrate);
                ui->cpuUserate->setText(QString::number(cpuUsedrate));
                rrate[nTimer] = (double)cpuUsedrate;
                //绘制曲线
                ui->customPlot->addGraph();
                ui->customPlot->graph(0)->setData(tt, rrate);

                ui->customPlot->replot();


                nTimer++;
                if (nTimer > 120){
                    nTimer = 0;
                    for (int i = 0; i < 121; i++){
                        rrate[i] = 0;
                    }
                }
            }


        });
        timerTab0->start(1000);
    }

    //说明重启推出关机
    {
        connect(ui->btnExit, &QPushButton::clicked, this, [=](){
           exit(0);
        });

        connect(ui->btnRestart, &QPushButton::clicked, this, [=](){
            system("shutdown -r now");
        });
        connect(ui->btnClose, &QPushButton::clicked, this, [=](){
            system("shutdown -h now");
        });
    }

    //进程信息
    {
        //设置表格
        ui->tableWidgetProc->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->tableWidgetProc->setSelectionBehavior(QAbstractItemView::SelectRows); //整行选中的方式
        ui->tableWidgetProc->verticalHeader()->setVisible(false); //隐藏列表头
        //ui->tableWidgetProc->horizontalHeader()->setVisible(false); //隐藏行表头
        //ui->tableWidgetProc->setColumnCount(5);
        ui->tableWidgetProc->setHorizontalHeaderLabels(QStringList() << tr("PID")<<tr("名称")<<tr("状态")<<tr("优先级")<<tr("占用内存"));
        ui->tableWidgetProc->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); //自适应列宽
        //sheng ming

        //初始化
        this->refresh();

        //响应结束进程按钮
        connect(ui->btnProcDel, &QPushButton::clicked, this, [&](){
            int rowNow = ui->tableWidgetProc->currentRow();
            if (rowNow < 0) return;
            QString tempPid = ui->tableWidgetProc->item(rowNow, 0)->text();
            if  ( (QMessageBox::information(this, "删除进程", QString("是否要删除PID为%1的进程").arg(tempPid),
                                            QMessageBox::Yes | QMessageBox::Cancel, QMessageBox::Cancel)) == QMessageBox::Yes){
                //结束进程
                QString endProc = QString("kill -9 %1").arg(tempPid);
                QByteArray be = endProc.toLatin1();
                system(be.data());
            }
        });
        //响应刷新按钮
        connect(ui->btnProcF, &QPushButton::clicked, this, [&](){
           numOfSleep = 0;numOfZombie = 0;numOfRun = 0;numOfProc = 0;
           ui->tableWidgetProc->setRowCount(0);
           ui->tableWidgetProc->clearContents();
           this->refresh();
        });

    }

    //模块信息
    {
        //设置表格
        ui->tableWidgetModules->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->tableWidgetModules->setSelectionBehavior(QAbstractItemView::SelectRows); //整行选中的方式
        ui->tableWidgetModules->verticalHeader()->setVisible(false); //隐藏列表头

        ui->tableWidgetModules->setHorizontalHeaderLabels(QStringList() <<tr("名称")<<tr("占用内存")<<tr("使用次数"));
        ui->tableWidgetModules->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); //自适应列宽

        this->displayModulesInfo();

        connect(ui->btnReflashModules, &QPushButton::clicked, this, &Widget::displayModulesInfo);

        connect(ui->btnInsmod, &QPushButton::clicked, this, [=](){
//            QString filePath = QFileDialog::getOpenFileName(this, "选择.ko文件","/usr/src/","(*.ko)");
//            QFileInfo fileInfo = QFileInfo(filePath);
//            QString itsName = fileInfo.fileName();

//            QString sysInsmod = "sudo insmod "+filePath;
//            QByteArray ba = sysInsmod.toLatin1();
//            system(ba.data());

        });

    }
}

Widget::~Widget()
{
    delete ui;
}

void Widget::Sleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < dieTime )
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

int Widget::isDigitStr(QString src)
{
    QByteArray ba = src.toLatin1();
     const char *s = ba.data();

    while(*s && *s>='0' && *s<='9') s++;

    if (*s)
    {
        //不是纯数字
        return 0;
    }
    else
    {
        //纯数字
        return 1;
    }
}

void Widget::refresh(){
    QDir qd("/proc");
    QStringList qslist = qd.entryList();
    QString qs = qslist.join("\n");
    bool jLoop = true;
    int find_end,find_start = 0;

    QStringList procPid;

    while(jLoop){
        find_end = qs.indexOf("\n", find_start);
        if (find_end < 0) {
            jLoop = false;
            break;
        }
        QString tempName = qs.mid(find_start, find_end - find_start);
        if (this->isDigitStr(tempName)){
            numOfProc++;
            QString * tempp = new QString(tempName);
            procPid.push_back(*tempp);
        }
        find_start = find_end + 1;
    }

    qSort(procPid.begin(), procPid.end(),caseInsensitiveLessThan);
    for (QList<QString>::iterator it = procPid.begin(); it != procPid.end(); it++){
        this->addProcList(*it);
    }
    ui->labelProcing->setText(QString::number(numOfRun));
    ui->labelSleepProc->setText(QString::number(numOfSleep));
    ui->labelIceProc->setText(QString::number(numOfZombie));
    ui->labelTotalProc->setText(QString::number(numOfProc));
}

void Widget::addProcList(QString & tempName){
    //qDebug() << tempName <<endl;
    QFile fpid("/proc/"+tempName+"/stat");
    fpid.open(QIODevice::ReadOnly);
    //获取/proc/pid/stat文件
    QString pidStat = fpid.readAll();
    //进程名字
    QString procName = pidStat.section(' ',1 ,1);
    procName = procName.mid(1, procName.length()-2);
    //进程状态
    QString procState = pidStat.section(' ',2 ,2);
    char tempState = procState.at(0).unicode();

    switch(tempState)
    {
    case 'S':numOfSleep++;break;
    case 'Z':numOfZombie++;break;
    case 'R':numOfRun++;break;
    default:break;
    }
    //进程优先级
    QString procPriority = pidStat.section(' ',17,17);
    //进程内存使用
    QString procMemUse = pidStat.section(' ',22,22);
    int procMemUseInt = procMemUse.toInt() / 1024;
    //添加数据
    int rowCount = ui->tableWidgetProc->rowCount();
    ui->tableWidgetProc->insertRow(rowCount);
    ui->tableWidgetProc->setItem(rowCount, 0, new QTableWidgetItem(tempName));
    ui->tableWidgetProc->setItem(rowCount, 1, new QTableWidgetItem(procName));
    ui->tableWidgetProc->setItem(rowCount, 2, new QTableWidgetItem(QString(tempState)));
    ui->tableWidgetProc->setItem(rowCount, 3, new QTableWidgetItem(procPriority));
    ui->tableWidgetProc->setItem(rowCount, 4, new QTableWidgetItem(QString::number(procMemUseInt)+" MB"));
}

void Widget::displayModulesInfo(){
    QFile fmodule("/proc/modules");
    fmodule.open(QIODevice::ReadOnly);
    QString lineInfo;
    while( (lineInfo = fmodule.readLine()).isNull() == false ){

        QString mName = lineInfo.section(' ', 0, 0);
        QString mMemSize = lineInfo.section(' ', 1, 1);
        mMemSize = QString::number(mMemSize.toInt() / 1024);
        QString mUsedTimes = lineInfo.section(' ', 2, 2);
        //qDebug() << mName << ' ' <<mMemSize<<' '<<mUsedTimes<<endl;
        //添加数据
        int rowCount = ui->tableWidgetModules->rowCount();
        ui->tableWidgetModules->insertRow(rowCount);
        ui->tableWidgetModules->setItem(rowCount, 0, new QTableWidgetItem(mName));
        ui->tableWidgetModules->setItem(rowCount, 1, new QTableWidgetItem(mMemSize + " MB"));
        ui->tableWidgetModules->setItem(rowCount, 2, new QTableWidgetItem(QString(mUsedTimes)));

    }
    fmodule.close();
}
